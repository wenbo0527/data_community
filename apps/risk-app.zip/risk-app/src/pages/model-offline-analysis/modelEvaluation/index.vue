<template>
  <div class="page">
    <a-typography-title :heading="4">模型评估</a-typography-title>
    <a-card>
      <a-alert type="warning">这是独立应用的模型评估入口页面</a-alert>
    </a-card>
  </div>
</template>

<script setup>
</script>

<style scoped>
.page { padding: 16px; }
</style>
