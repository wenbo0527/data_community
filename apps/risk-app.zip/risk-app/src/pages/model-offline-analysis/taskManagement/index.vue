<template>
  <div class="page">
    <a-typography-title :heading="4">任务管理</a-typography-title>
    <a-card>
      <a-alert type="success">这是独立应用的任务管理入口页面</a-alert>
    </a-card>
  </div>
</template>

<script setup>
</script>

<style scoped>
.page { padding: 16px; }
</style>
