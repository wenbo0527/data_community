<template>
  <div class="tab-block">
    <div class="tab-toolbar">
      <a-radio-group v-model="innerRange" @change="onRangeChange" size="small">
        <a-radio value="month">月度</a-radio>
        <a-radio value="quarter">季度</a-radio>
      </a-radio-group>
    </div>
    <div class="content">
      <a-descriptions :column="3" bordered>
        <a-descriptions-item label="平台产品">{{ platform }}</a-descriptions-item>
        <a-descriptions-item label="业务类型">{{ businessType }}</a-descriptions-item>
        <a-descriptions-item label="时间范围">{{ innerRangeLabel }}</a-descriptions-item>
      </a-descriptions>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'

const props = defineProps({
  platform: { type: String, required: true },
  businessType: { type: String, required: true },
  timeRange: { type: String as () => 'month' | 'quarter', required: true }
})
const emit = defineEmits(['time-range-change'])

const innerRange = ref<'month' | 'quarter'>(props.timeRange)
watch(() => props.timeRange, (v) => { innerRange.value = v })
const onRangeChange = (val: 'month' | 'quarter') => { emit('time-range-change', val) }
const innerRangeLabel = computed(() => innerRange.value === 'month' ? '月度' : '季度')
</script>

<style scoped>
.tab-block { width: 100%; }
.tab-toolbar { display: flex; justify-content: flex-end; margin-bottom: 8px; }
.content { width: 100%; }
</style>
