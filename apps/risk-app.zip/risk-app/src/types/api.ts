export interface ErrorType {
  code: string
  message: string
}
