<template>
  <div class="contract-detail">
    <a-page-header title="合同详情" />
    <a-card>
      <a-descriptions :column="2" :data="items" bordered />
    </a-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { getContractList } from '../api/contract'
const route = useRoute()
const id = String(route.params.id || '')
const data = ref<any>({})
const items = computed(() => [
  { label: '合同名称', value: data.value?.contractName || '—' },
  { label: '合同编号', value: data.value?.contractNo || '—' },
  { label: '供应商', value: data.value?.supplier || '—' },
  { label: '金额', value: data.value?.amount || '—' },
  { label: '开始日期', value: data.value?.startDate || '—' },
  { label: '结束日期', value: data.value?.endDate || '—' }
])
const load = async () => { const res = await getContractList({ page: 1, pageSize: 100 }); data.value = (res.list || []).find((x: any) => String(x.id) === id) || {} }
onMounted(load)
</script>

<style scoped>
</style>
