<template>
  <div class="contract-management">
    <div class="page-header">
      <h3>合同管理</h3>
      <p class="desc">合同统计、趋势与到期预警，按供应商维度分析</p>
    </div>
    <a-card class="toolbar" :bordered="true">
      <a-form :model="filters" layout="inline">
        <a-form-item field="supplier" label="供应商">
          <a-select v-model="filters.supplier" placeholder="选择供应商" allow-clear style="width: 180px">
            <a-option v-for="s in supplierOptions" :key="s" :value="s">{{ s }}</a-option>
          </a-select>
        </a-form-item>
        <a-form-item field="contractType" label="合同类型">
          <a-select v-model="filters.contractType" placeholder="全部类型" allow-clear style="width: 160px">
            <a-option value="framework">框架协议</a-option>
            <a-option value="supplement">补充合同</a-option>
          </a-select>
        </a-form-item>
        <a-form-item field="status" label="状态">
          <a-select v-model="filters.status" placeholder="选择状态" allow-clear style="width: 160px">
            <a-option value="active">进行中</a-option>
            <a-option value="pending">待生效</a-option>
            <a-option value="expired">已到期</a-option>
          </a-select>
        </a-form-item>
        <a-form-item>
          <a-button type="primary" @click="applyFilter">查询</a-button>
          <a-button style="margin-left: 8px" @click="resetFilter">重置</a-button>
        </a-form-item>
        <a-form-item>
          <a-button type="primary" @click="goCreatePage">
            <template #icon>
              <IconUpload />
            </template>
            合同上传
          </a-button>
        </a-form-item>
        <a-form-item>
          <a-button @click="showSupplierModal = true">新增供应商</a-button>
        </a-form-item>
        <a-form-item>
          <a-dropdown @select="handleSettlementSelect">
            <a-button type="primary">
              结算 <IconDown />
            </a-button>
            <template #content>
              <a-doption value="initiate">发起结算</a-doption>
              <a-doption value="list">进入结算列表页</a-doption>
            </template>
          </a-dropdown>
        </a-form-item>
      </a-form>
    </a-card>
    <a-grid :cols="4" :col-gap="12" :row-gap="12" class="stats">
      <a-grid-item>
        <a-card hoverable>
          <a-statistic title="生效合同数" :value="stats.count" />
        </a-card>
      </a-grid-item>
      <a-grid-item>
        <a-card hoverable>
          <a-statistic title="合同剩余总金额" :value="stats.totalAmount">
            <template #suffix>元</template>
          </a-statistic>
        </a-card>
      </a-grid-item>
      <a-grid-item>
        <a-card hoverable>
          <a-statistic title="到期预警合同数" :value="supplierSummary.filter(i=>i.totalAmount>0).length" />
        </a-card>
      </a-grid-item>
      <a-grid-item>
        <a-card hoverable>
          <a-statistic title="供应商数量" :value="stats.supplierCount" />
        </a-card>
      </a-grid-item>
    </a-grid>
    <a-card title="供应商维度分析">
      <a-table :data="supplierSummary" :pagination="false" :bordered="{ wrapper: true, cell: true }">
        <template #columns>
          <a-table-column title="供应商">
            <template #cell="{ record }">
              <a-link @click="filterBySupplier(record.supplier)">{{ record.supplier }}</a-link>
            </template>
          </a-table-column>
          <a-table-column title="合同数" data-index="count" />
          <a-table-column title="关联外数产品" :width="180">
            <template #cell="{ record }">{{ record.productCount ?? '—' }}</template>
          </a-table-column>
          <a-table-column title="剩余总额" :width="180">
            <template #cell="{ record }">{{ formatAmount(record.totalAmount) }}</template>
          </a-table-column>
        </template>
      </a-table>
    </a-card>
    <a-card title="合同列表" :loading="loading">
      <a-table :data="tableData" row-key="id" :pagination="pagination" @page-change="onPageChange"
        @row-click="openContractDetail">
        <template #columns>
          <a-table-column title="合同名称" data-index="contractName" :width="240" />
          <a-table-column title="类型" :width="120">
            <template #cell="{ record }">{{ record.contractType === 'supplement' ? '补充合同' : '框架协议' }}</template>
          </a-table-column>
          <a-table-column title="关联框架协议" :width="240">
            <template #cell="{ record }">
              <span v-if="record.contractType === 'supplement'">{{ frameworkLabel(record.frameworkId) }}</span>
              <span v-else>—</span>
            </template>
          </a-table-column>
          <a-table-column title="合同总金额" :width="160">
            <template #cell="{ record }">{{ formatAmount(record.amount) }}</template>
          </a-table-column>
          <a-table-column title="合同数据条数" :width="160">
            <template #cell="{ record }">{{ record.dataCount ?? '—' }}</template>
          </a-table-column>
          <a-table-column title="关联产品数" :width="140">
            <template #cell="{ record }">{{ record.productCount ?? '—' }}</template>
          </a-table-column>
          <a-table-column title="已核销金额" :width="160">
            <template #cell="{ record }">{{ formatAmount(record.writtenOffAmount) }}</template>
          </a-table-column>
        </template>
      </a-table>
    </a-card>
    <a-modal v-model:visible="showSupplierModal" title="新增供应商" :width="600" @ok="submitSupplier"
      @cancel="resetSupplierForm">
      <a-form ref="supplierFormRef" :model="supplierForm" :rules="supplierFormRules" layout="vertical">
        <a-form-item label="供应商名称" field="name" required>
          <a-input v-model="supplierForm.name" placeholder="请输入供应商名称" />
        </a-form-item>
        <a-form-item label="供应商说明" field="description" required>
          <a-textarea v-model="supplierForm.description" placeholder="请输入供应商说明" :rows="3" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Message } from '@arco-design/web-vue'
import { IconUpload, IconDown } from '@arco-design/web-vue/es/icon'
import { useContractStore } from '../stores/contract'
import type { ContractItem } from '../stores/contract'
import { useSettlementSupplier } from '../composables/useSettlementSupplier'

const store = useContractStore()
const router = useRouter()
const { supplierOptions: settlementSupplierOptions, loadSuppliers } = useSettlementSupplier()
const loading = computed(() => store.loading)
const list = computed(() => store.list)
const tableData = computed(() => {
  const base = list.value
  if (!filters.contractType) return base
  return base.filter((i: any) => i.contractType === filters.contractType)
})
const stats = computed(() => store.stats)

const current = ref(1)
const pageSize = ref(10)
const pagination = reactive({ total: 0, pageSize: pageSize.value, current: current.value, showTotal: (total: number) => `共 ${total} 条合同` })

const filters = reactive<{ supplier?: string; status?: string; contractType?: 'framework' | 'supplement' | undefined }>({ supplier: undefined, status: undefined, contractType: undefined })

const supplierRegistry = ref<{ name: string; description: string }[]>([])
const supplierOptions = computed(() => Array.from(new Set([
  ...list.value.map((i: ContractItem) => i.supplier), ...supplierRegistry.value.map((s: { name: string; description: string }) => s.name)
].filter(Boolean))))

const applyFilter = async () => { await store.fetchContractList({ page: 1, pageSize: pageSize.value, supplier: filters.supplier, status: filters.status }); pagination.total = store.total }
const resetFilter = async () => { filters.supplier = undefined; filters.status = undefined; filters.contractType = undefined; await applyFilter() }
const filterBySupplier = async (supplier: string) => { filters.supplier = supplier; await applyFilter() }
const goCreatePage = () => { router.push('/budget/contracts/create') }

const showSupplierModal = ref(false)
const supplierFormRef = ref()
const supplierForm = reactive({ name: '', description: '' })
const supplierFormRules = { name: [{ required: true, message: '请输入供应商名称' }], description: [{ required: true, message: '请输入供应商说明' }] }
const submitSupplier = async () => { const valid = await supplierFormRef.value?.validate(); if (!valid) return; supplierRegistry.value.unshift({ name: supplierForm.name, description: supplierForm.description }); Message.success('新增供应商成功'); showSupplierModal.value = false; resetSupplierForm() }
const resetSupplierForm = () => { supplierForm.name = ''; supplierForm.description = ''; supplierFormRef.value?.clearValidate() }

const formatAmount = (n?: number) => { if (!n && n !== 0) return '—'; return Number(n).toLocaleString('zh-CN', { style: 'currency', currency: 'CNY' }) }
const frameworkLabel = (id?: string | null) => { if (!id) return '—'; const m = store.list.find(i => i.id === id); return m ? `${m.contractName}（${m.contractNo}）` : id }

const onPageChange = async (page: number) => { current.value = page; await applyFilter() }
const openContractDetail = (record: ContractItem) => { router.push(`/budget/contracts/${record.id}`) }

const supplierSummary = computed(() => { const map = new Map<string, { supplier: string; count: number; totalAmount: number; expiringCount: number; productCount: number }>(); list.value.forEach((i: ContractItem) => { const key = i.supplier || '—'; const bucket = map.get(key) || { supplier: key, count: 0, totalAmount: 0, expiringCount: 0, productCount: 0 }; bucket.count += 1; bucket.totalAmount += Number(i.amount) || 0; bucket.productCount += Number(i.productCount) || 0; map.set(key, bucket) }); return Array.from(map.values()) })

const handleSettlementSelect = (value: string | number | Record<string, any> | undefined) => {
  if (value === 'initiate') {
    router.push('/budget/settlement?action=initiate')
  } else if (value === 'list') {
    router.push('/budget/settlement')
  }
}

onMounted(async () => { await store.fetchContractList({ page: current.value, pageSize: pageSize.value }); pagination.total = store.total; try { await loadSuppliers() } catch {} })
</script>

<style scoped>
.page-header {
  margin-bottom: 12px;
}
.desc {
  color: var(--color-text-2);
}
.toolbar {
  margin-bottom: 12px;
}
.stats {
  margin-bottom: 12px;
}
</style>
