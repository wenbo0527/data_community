import http from '../../../api/http'
const useMock = (import.meta as any)?.env?.VITE_USE_MOCK === 'true'

export async function getBurndown(params: any) {
  if (useMock) {
    const months = ['01','02','03','04','05','06','07','08','09','10','11','12']
    const initial = 1000000
    const data = months.map((m, i) => ({
      granularity: 'month',
      month: `${new Date().getFullYear()}-${m}`,
      budget: initial - i * 60000,
      actual: initial - i * 50000,
      initialBudget: initial
    }))
    return data
  }
  try {
    const payload = await http.get('budget/monitor/burndown', { params })
    const list = Array.isArray(payload) ? payload : (payload?.data ?? [])
    if (Array.isArray(list) && list.length) return list
  } catch {}
  const months = ['01','02','03','04','05','06','07','08','09','10','11','12']
  const initial = 1000000
  return months.map((m, i) => ({
    granularity: 'month',
    month: `${new Date().getFullYear()}-${m}`,
    budget: initial - i * 60000,
    actual: initial - i * 50000,
    initialBudget: initial
  }))
}

export async function getWarnings(params: any) {
  if (useMock) {
    const list = Array.from({ length: 8 }, (_, i) => ({
      id: i + 1,
      level: i % 3 === 0 ? 'critical' : i % 3 === 1 ? 'warning' : 'info',
      message: `预算偏离预警-${i + 1}`,
      createdAt: new Date(Date.now() - i * 3600000).toISOString(),
      businessType: ['授信','营销','风控'][i % 3],
      platform: ['供应商A','供应商B','供应商C'][i % 3],
      estimatedCost: 100000 + i * 5000,
      actualCost: 110000 + i * 6000,
      estimatedLoan: 500000 + i * 10000,
      actualLoan: 450000 + i * 9000
    }))
    return list
  }
  try {
    const payload = await http.get('budget/monitor/warnings', { params })
    const list = Array.isArray(payload) ? payload : (payload?.data ?? [])
    if (Array.isArray(list) && list.length) return list
  } catch {}
  const list = Array.from({ length: 8 }, (_, i) => ({
    id: i + 1,
    level: i % 3 === 0 ? 'critical' : i % 3 === 1 ? 'warning' : 'info',
    message: `预算偏离预警-${i + 1}`,
    createdAt: new Date(Date.now() - i * 3600000).toISOString(),
    businessType: ['授信','营销','风控'][i % 3],
    platform: ['供应商A','供应商B','供应商C'][i % 3],
    estimatedCost: 100000 + i * 5000,
    actualCost: 110000 + i * 6000,
    estimatedLoan: 500000 + i * 10000,
    actualLoan: 450000 + i * 9000
  }))
  return list
}
