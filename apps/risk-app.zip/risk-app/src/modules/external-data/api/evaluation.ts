import http from '../../../api/http'
const useMock = (import.meta as any)?.env?.VITE_USE_MOCK === 'true'

export async function getEvaluationReports(params: any) {
  if (useMock) {
    const list = Array.from({ length: 12 }, (_, i) => ({
      id: i + 1,
      title: `评估报告-${i + 1}`,
      type: ['quality', 'performance', 'cost_effectiveness', 'comprehensive'][i % 4],
      status: ['draft', 'in_progress', 'completed', 'archived'][i % 4],
      score: 70 + (i % 30),
      createdAt: new Date(Date.now() - i * 86400000).toISOString()
    }))
    return { list, total: list.length }
  }
  const data = await http.get('/external-data-evaluation/list', { params })
  const list = Array.isArray((data as any)?.list) ? (data as any).list : (Array.isArray(data) ? data : (data as any)?.data ?? [])
  const total = Number((data as any)?.total ?? (Array.isArray(list) ? list.length : 0))
  return { list, total }
}

export async function getEvaluationReportDetail(id: string | number) {
  if (useMock) {
    return {
      id,
      title: `评估报告-${id}`,
      status: 'completed',
      score: 85,
      content: { summary: '示例评估内容' },
      fields: { latency: '120ms', availability: '99.9%' },
      createdAt: new Date().toISOString()
    }
  }
  return await http.get(`/external-data-evaluation/${id}`)
}

export async function createEvaluationReport(payload: any) {
  if (useMock) return { id: Date.now(), ...payload }
  return await http.post('/external-data-evaluation', payload)
}

export async function publishReport(id: string | number) {
  if (useMock) return { id, status: 'completed' }
  return await http.put(`/external-data-evaluation/${id}/publish`)
}

export async function archiveReport(id: string | number) {
  if (useMock) return { id, status: 'archived' }
  return await http.put(`/external-data-evaluation/${id}/archive`)
}

export async function getRegisteredProducts() {
  if (useMock) {
    const data = [
      { id: 1, name: '产品A', supplier: '供应商A', status: 'online', interfaces: 2, unitPrice: 3.5 },
      { id: 2, name: '产品B', supplier: '供应商B', status: 'importing', interfaces: 1, unitPrice: 2.0 },
      { id: 3, name: '产品C', supplier: '供应商C', status: 'pending_evaluation', interfaces: 3, unitPrice: 4.2 },
      { id: 4, name: '产品D', supplier: '供应商D', status: 'archived', interfaces: 0, unitPrice: 1.8 }
    ]
    return { data }
  }
  return await http.get('/external-data-evaluation/products')
}
